import React from "react";

import Header from "../components/Header";
import Receipt from "../components/Receipt";
import Footer from "../components/Footer";

export default function ReceiptPage() {

   

  return (
    <div>
      <Header />
      <Receipt />
   
      <Footer />
    </div>
  );
}
