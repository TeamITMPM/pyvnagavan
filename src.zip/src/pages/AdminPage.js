import React from "react";
import AdminPanel from "../components/AdminPanel";

const AdminPage = () => {
  return (
    <>
      <AdminPanel />
      <div> AAAAAAAA</div>
    </>
  );
};
export default AdminPage;
