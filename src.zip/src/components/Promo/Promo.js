import React from 'react'

import styles from "./Promo.module.css"

export default function Promo() {
  return (
    <div>Promo</div>
  )
}
