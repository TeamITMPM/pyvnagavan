export {default} from "./UserRegistration"

