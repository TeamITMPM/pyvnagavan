import styles from "./PlaceholderDesc.module.css";

export default function PlaceholderDesc() {
  return (
    <>
      <div>
        <p className={styles.p}>
          <b>--:</b> <i>--</i>
        </p>
      </div>
      <div>
        <p className={styles.p}>
          <b>--:</b> <i>--</i>
        </p>
      </div>
      <div>
        <p className={styles.p}>
          <b>--:</b> <i>--</i>
        </p>
      </div>
      <div>
        <p className={styles.p}>
          <b>--:</b> <i>--</i>
        </p>
      </div>
      <div>
        <p className={styles.p}>
          <b>--:</b> <i>--</i>
        </p>
      </div>
      <div>
        <p className={styles.p}>
          <b>--:</b> <i>--</i>
        </p>
      </div>
    </>
  );
}
